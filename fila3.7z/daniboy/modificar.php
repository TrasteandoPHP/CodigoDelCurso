<?php
session_start();
if (isset($_SESSION['usuario']))
    {
        $conexion=new mysqli("localhost","fila3","fila3","fila3");
        if ($formulario="empleados")
        {
            $formulario=$_GET["form"];
            $cod=$_GET["cod"];

            $conexion=new mysqli("localhost","fila3","fila3","fila3");
            $sqlconsulta="SELECT * FROM empleados WHERE cod_emp=$cod";
            $ej=$conexion->query($sqlconsulta);
            $reg=$ej->fetch_array();
            
            $codmovil=$reg['cod_mov'];
            $sqlconsultamovil="SELECT * FROM moviles WHERE cod_mov=$codmovil";
            $ejmovil=$conexion->query($sqlconsultamovil);
            $regmovil=$ejmovil->fetch_array();
            
?>
<form action="grabamodificacion.php" method="post">
        <input type="text" name="nombre" value="<?= $reg['nom_emp']?>" placeholder="Nombre empleado..." required>
        <input type="text" name="apellido" value="<?= $reg['ape_emp']?>" placeholder="Apellido empleado..." required>
        <input type="text" name="email" value="<?= $reg['email_emp']?>"  placeholder="Email..." required>
        <input type="hidden" name="codempleado" value="<?= $reg['cod_emp']?>">
        
        <select name="numero">
            <option value="codmovil"><?= $regmovil['num_mov']," - ", $regmovil['mar_mov']?></option>

            <?php
                $conexion=new mysqli("localhost","fila3","fila3","fila3");
                $sqlconsulta="SELECT * FROM moviles WHERE est_mov='0'";
                $ejsql=$conexion->query($sqlconsulta);
                foreach ($ejsql as $registro) {
                    
                    $codmovil=$registro["cod_mov"];
                    $num=$registro["num_mov"];
                    $marca=$registro["mar_mov"];
                    
                ?>
                    <option value="<?php echo $codmovil?>"><?php echo "$num - $marca";?></option>
                <?php
                    
                }
                ?>

        </select>

        <input type="hidden" name="codmovil" value="<?php echo $codmovil?>">

        <input class="btn btn-success mt-3" type="submit" value="GRABAR">
</form>
<?php
    }
    }
    else

    {
        ?>
        <script>
            alert("No has iniciado session");
            window.location.href="./../peche/login.php";
        </script>
<?php
    }
?>