<?php
session_start();
if(!isset($_SESSION["usuario"])){
    echo "<script>
    alert('Tienes que iniciar session');
    window.location.href='login.php'
    </script>";
}
else
{
$con=new mysqli("localhost","fila3","fila3","fila3");

$sql="SELECT * FROM asignaciones inner join empleados using(cod_emp) inner join vehiculos using(cod_veh)";
$sqlv="";

$eje=$con->query($sql);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <title>Document</title>
</head>


<body> 
   <div class="container">
    <div class="row">
    <?php include("./../manuelcp/navegacion.html");  ?>
        <div class="offset-3 col-6">
      
   
   <center><h1>CONSULTA ASIGNACIONES</h1></center>
   <table class="table table-striped">
   <th>Codigo</th>
   <th>Cod Vehiculo</th>
   <th>Cod Empleado</th>
   <th>Nombre</th>
   <th>Fecha</th>
<tr>

        </div>
    </div>
   </div>
<?php
foreach($eje as $reg)
{
    echo "<tr>
    <td>".$reg['cod_asi']."</td>
    <td>".$reg['mat_veh']."</td>
    <td>".$reg['cod_emp']."</td>
    <td>".$reg['nom_emp']."</td>
    <td>".$reg['fecha_asi']."</td>
    </tr>";
}
?>



</table>


</body>
<?php 
}
?>
</html> 


