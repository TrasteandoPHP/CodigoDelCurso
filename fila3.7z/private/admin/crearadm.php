<?php
$nom=$_POST["nomadm"];
$ema=$_POST["emaadm"];
$pas=$_POST["pwsadm"];
$pas=password_hash($pas,PASSWORD_DEFAULT);
$con=new mysqli("localhost","fila3","fila3","fila3");
$sql="INSERT INTO administradores (nom_adm,ema_adm,pas_adm) VALUES ('$nom','$ema','$pas')";

if($con->query($sql))
{
echo "GRABADO CORRECTAMENTE";
}
else
{
echo "ERROR";
}


?>