<?php
function conexion(){
return new mysqli("localhost","fila3","fila3","fila3");
}
function consulta($tabla,$valor){
$sql="SELECT * FROM $tabla WHERE $valor";
 return conexion()->query($sql);
}

function actualiza($tabla,$campos,$valor){
$sql="UPDATE $tabla SET $campos WHERE $valor";
return conexion()->query($sql);
}
function insertar($tabla,$campos,$valor){
    $sql="INSERT INTO $tabla $campos VALUES $valor";
    return conexion()->query($sql);
}

function verifica($tabla,$valor1,$valor2)
{
$sql="SELECT * FROM $tabla WHERE ema_adm='$valor1'";
$result=conexion()->query($sql);
if($reg=$result->fetch_array())
{
    if(password_verify($valor2,$reg['pas_adm'])){
return $reg['cod_adm'];
    }
    else
    {
        //return "";
    }
    
}
}
function mensaje($mensaje,$redir){
    if($mensaje)
    {echo "
    <script>
        alert('$mensaje');
        window.location.href='$redir';
    </script>
";   
    }
    else
    {
        echo "
    <script>
        window.location.href='$redir';
    </script>";
    }

}
function consultamultiple($tabla,$valor1,$valor2){
$sql="SELECT * FROM $tabla INNER JOIN $valor1 $valor2";
return $eje=conexion()->query($sql); 
}    
function existe($tabla,$cond){
$sql="SELECT * FROM $tabla WHERE $cond";
$ejec=conexion()->query($sql);
return $ejec->fetch_array();
}
?>