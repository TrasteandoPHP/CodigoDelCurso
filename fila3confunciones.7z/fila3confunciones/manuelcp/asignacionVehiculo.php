<?php
    $codigoEmpleado = $_POST["empleado"];
    $codigoVehiculo = $_POST["vehiculo"];
    $fecha = date("Y-m-d");
require_once("./../peche/funciones/funciones.php");
    if(insertar("asignaciones","(cod_emp, cod_veh, fecha_asi)","('$codigoEmpleado','$codigoVehiculo','$fecha')")){
        echo "
                <script>
                    alert('Asignación de Vehículo registrada correctamente.');
                </script>
            ";    
        if(actualiza("empleados","est_veh=1","cod_emp='$codigoEmpleado'"))
{               if(actualiza("vehiculos","est_veh=1","cod_veh='$codigoVehiculo'")){
                    echo "
                    <script>
                        window.location.href='./altaVehiculos.php';
                    </script>
                ";      

                } else {
                    echo "
                        <script>
                            alert('Error durante la grabación. Inténtelo de nuevo');
                            window.location.href='./altaVehiculos.php';
                        </script>
                    ";     
                }

        } else {
            echo "
                <script>
                    alert('Error durante la grabación. Inténtelo de nuevo');
                    window.location.href='./altaVehiculos.php';
                </script>
            ";     
        }
      

    } else {
        echo "
                <script>
                    alert('Error durante la grabación. Inténtelo de nuevo');
                    window.location.href='./altaVehiculos.php';
                </script>
            ";     
    }
?>