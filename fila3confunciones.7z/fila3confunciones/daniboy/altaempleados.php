<?php
session_start();
require_once("./../peche/funciones/funciones.php");
if (isset($_SESSION['usuario']))
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <title>Alta empleados</title>
</head>
<body>
<div class="container">
    <div class="row">
        <?php
            include("./../manuelcp/navegacion.html")
        ?>
        <div class="offset-1 col-10 text-center">
<main>
    <form action="altaempleados.php" method="post">
        <input type="text" name="nombre" placeholder="Nombre empleado..." required>
        <input type="text" name="apellido" placeholder="Apellido empleado..." required>
        <input type="text" name="email" placeholder="Email..." required>
        <select name="numero" required>
            <option>Selecciona Numero</option>
                <?php
                $ejsql=consulta("moviles","est_mov=0");
                foreach ($ejsql as $registro) {
                    $codmovil=$registro["cod_mov"];
                    $num=$registro["num_mov"];
                    $marca=$registro["mar_mov"];
                   echo "<option value=$codmovil> $num - $marca</option>";
                }
                ?>
        </select>
        <br><input class="btn btn-success mt-3" type="submit" value="GRABAR">
    </form>
    <?php
    
    if (isset($_POST["nombre"]))
    {
    $numero=$_POST["numero"];
    $nombre=$_POST["nombre"];
    $apellido=$_POST["apellido"];
    $email=$_POST["email"];
    if(!existe("empleados","email_emp='$email'")){
      if(insertar("empleados","(cod_mov,nom_emp,ape_emp,email_emp)","('$numero','$nombre','$apellido','$email')"))
      {
    if(actualiza("moviles","est_mov=1","cod_mov='$numero'"))
    {
        mensaje("Movil Grabado","");
    }
    else{}
      }
else{
    mensaje("Ocurrio Error","");
}
}
else{
    mensaje("No se puede Grabar Email Registrado","");
}

}
?>
<table class="table table-striped mt-5">
    <tr>
        <th>Numeros Ocupados</th><th>Número</th><th>Marca</th>
    </tr>
<?php
$conexion=new mysqli("localhost","fila3","fila3","fila3");
$ejsql=consultamultiple("empleados","moviles","USING(cod_mov) WHERE est_mov=1");
foreach ($ejsql as $registro) {
    $cod=$registro["cod_emp"];
    $nom=$registro["nom_emp"];
    $num=$registro["num_mov"];
    $marca=$registro["mar_mov"];

echo "
    <tr>
        <td><a href='modificar.php?form=empleados&cod=$cod'>$nom</a></td>
        <td><$num</td>
        <td><$marca</td>
    </tr>
    ";
        }
?>
</main>
        </div>
    </div>
</div>
</body>
</html>
<?php
}
else
{
    ?>
    <script>
        alert("No has iniciado session");
        window.location.href="./../peche/login.php";
    </script>
    
    <?php
}
?>
