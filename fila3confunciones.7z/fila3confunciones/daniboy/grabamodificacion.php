<?php
$nombre=$_POST["nombre"];
$apellido=$_POST["apellido"];
$email=$_POST["email"];
$codempleado=$_POST["codempleado"];
$codmovil=$_POST["codmovil"];
$numero=$_POST["numero"];


function actualiza($tabla,$valor){

    $conexion=new mysqli("10.10.10.199","fila3","fila3","fila3");
    $sqlactualiza="UPDATE $tabla SET $valor";
    return $conexion->query($sqlactualiza);

}

if (actualiza("empleados","cod_mov='$numero',nom_emp='$nombre',ape_emp='$apellido',email_emp='$email' WHERE cod_emp='$codempleado'"))

//ME FALTA EL UPDATE del estado del movil de 0 a 1 y listo!!!!

{
    ?>
        <script>
            alert("Empleado actualizado");
            window.location.href="./altaempleados.php";
        </script>
    <?php
}
else
{

}


?>