<?php


	$conexion = new mysqli("10.10.10.199","juego","1234","ahorcado");
	$sql = "SELECT * FROM palabras ORDER BY rand() LIMIT 1";
	$ej = $conexion->query($sql);
	$reg = $ej->fetch_array();
	
	$datos = array($reg["pal_pal"],$reg["letras_pal"]);

	echo json_encode($datos);


?>