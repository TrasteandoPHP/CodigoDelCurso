<?php
	//recoger datos del alta.html
	$miarray = $_POST["dato"];
	$arraybien = json_decode($miarray);

	$conexion = new mysqli("10.10.10.199","juego","1234","ahorcado");
	$sqlbus = "SELECT * FROM palabras WHERE pal_pal='$arraybien[0]'";
	$ejebus = $conexion->query($sqlbus);
	if($ejebus->fetch_array())
	{
		//existe
		echo "Palabra ya existe";
	}
	else
	{
		//no existe grabo
		$sqlgra = "INSERT INTO palabras (pal_pal, letras_pal) VALUES ('$arraybien[0]','$arraybien[1]')";
		if($conexion->query($sqlgra))
		{
			//grabó 
			echo "palabra registrada";
		}
		else
		{
			//no grabó
			echo "Ocurrió un error";
		}	
	}	





?>