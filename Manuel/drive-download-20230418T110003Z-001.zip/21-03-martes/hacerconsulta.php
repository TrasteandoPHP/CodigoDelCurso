<?php

	include("clases.php");
	$alumnos = new Consultar("alumnos","");
	$todos = $alumnos->haz_query();
	$numalumnos = $alumnos->haz_cuenta();
	foreach($todos as $registro)
								{
									$cod = $registro["cod_alu"];	
									$nom = $registro["nom_alu"];
									$ap = $registro["ap_alu"];
									$ema = $registro["email_alu"];
									//vamos a explotar el apellido PERO ojo porque tenemos un problema
									$trozos = explode(" ",$ap);
									$ap1 = $trozos[0];
									$ap2 = "";
									for($i=1;$i<count($trozos);$i++)
									{
										$ap2 .= $trozos[$i]." "; 
									}
									?>
										<tr id="tr<?php echo $cod;?>">
											<form action="asd.php">
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $nom;?>
												</span> 
												<input id="in<?php echo $cod;?>"  ondblclick="apagar(<?php echo $cod?>)"type="text" name="nombre" value="<?php echo $nom;?>"style="display:none">
											</td>
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $ap1;?>
												</span>
												<input id="ing<?php echo $cod;?>"  ondblclick="apagar(<?php echo $cod?>)"type="text" name="ap1" value="<?php echo $ap1;?>"style="display:none">
											</td>
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $ap2;?>
												</span> 
												<input ondblclick="apagar(<?php echo $cod?>)" id="in<?php echo $cod;?>" type="text" name="ap2" value="<?php echo $ap2;?>"style="display:none">
											</td>
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $ema;?>
												</span> 
												<input id="in<?php echo $cod;?>" ondblclick="apagar(<?php echo $cod?>)" type="text" name="email" value="<?php echo $ema;?>"style="display:none">
											</td>
											<input type="hidden" value="<?php echo $cod?>" name="codigoalumno">
											<td>
												<button class="btn btn-success"><i class="fa fa-edit"></i></button>
												
												<button class="btn btn-danger"><i class="fa fa-trash"></i></button>
											</td>
											</form>	
										</tr>
									<?php
								}


?>