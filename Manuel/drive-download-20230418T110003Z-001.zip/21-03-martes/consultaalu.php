<?php
	include("clases.php");
	$alumnos = new Consultar("alumnos","");
	$todos = $alumnos->haz_query();
	$numalumnos = $alumnos->haz_cuenta();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
	<script src="https://kit.fontawesome.com/7b8eabe9ec.js" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.quicksearch/2.4.0/jquery.quicksearch.js" integrity="sha512-U+KdQxKTQfGIQJBs2QyDiU3PxJoSu+ffUJV5AAuMmwSFs1CjBz5Xk3/qWrT0mBHOM/C15q3DMko6HJL+37MYNA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body>
	<div class="container">
		<div class="row">
			<button class="btn btn-primary" onclick="window.location.href='index.html'"><i class="fa fa-home" ></i></button>
		</div>	
		<div class="row">
			<div class="col-12">
				<h4 class="text-center">Consulta alumnado <span id="numeroregistros"><?php echo $numalumnos?> </span> <i id="embudo" class="fa fa-filter text-primary" style="display:none"></i></h4>
			</div>
			<div class="col-12">
				<div class="row">
					<input type="text" id="busca" placeholder="Buscar..." class="form-control" onkeyup="contar()">
				</div>
				<div class="row py-4">
					<table class="table table-striped">
						<thead>
							<tr class="table table-dark">
								<th>Nombre</th>
								<th>Primer Apellido</th>
								<th>Segundo Apellido</th>
								<th>Email</th>
								<th></th>
							</tr>	
						</thead>
						<tbody>
							<?php
								foreach($todos as $registro)
								{
									$cod = $registro["cod_alu"];	
									$nom = $registro["nom_alu"];
									$ap = $registro["ap_alu"];
									$ema = $registro["email_alu"];
									//vamos a explotar el apellido PERO ojo porque tenemos un problema
									$trozos = explode(" ",$ap);
									$ap1 = $trozos[0];
									$ap2 = "";
									for($i=1;$i<count($trozos);$i++)
									{
										$ap2 .= $trozos[$i]." "; 
									}
									?>
										<tr id="tr<?php echo $cod;?>">
											<form action="asd.php">
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $nom;?>
												</span> 
												<input id="in<?php echo $cod;?>"  ondblclick="apagar(<?php echo $cod?>)"type="text" name="nombre" value="<?php echo $nom;?>"style="display:none">
											</td>
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $ap1;?>
												</span>
												<input id="ing<?php echo $cod;?>"  ondblclick="apagar(<?php echo $cod?>)"type="text" name="ap1" value="<?php echo $ap1;?>"style="display:none">
											</td>
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $ap2;?>
												</span> 
												<input ondblclick="apagar(<?php echo $cod?>)" id="in<?php echo $cod;?>" type="text" name="ap2" value="<?php echo $ap2;?>"style="display:none">
											</td>
											<td>
												<span id="<?php echo $cod;?>" ondblclick="encender(this.id)">
													<?php echo $ema;?>
												</span> 
												<input id="in<?php echo $cod;?>" ondblclick="apagar(<?php echo $cod?>)" type="text" name="email" value="<?php echo $ema;?>"style="display:none">
											</td>
											<input type="hidden" value="<?php echo $cod?>" name="codigoalumno">
											<td>
												<button class="btn btn-success"><i class="fa fa-edit"></i></button>
												
												<button class="btn btn-danger"><i class="fa fa-trash"></i></button>
											</td>
											</form>	
										</tr>
									<?php
								}
							?>
						</tbody>
					</table>					
				</div>
			</div>
		</div>
	</div>

	<script>
		
		function encender(iden)
		{
			
			$("#tr"+iden+" td input").show();
			$("#tr"+iden+" td span").hide();
			
		}

		function apagar(iden)
		{
			
			$("#tr"+iden+" td input").hide();
			$("#tr"+iden+" td span").show();
			
		}

		function contar()
		{
			$("#busca").quicksearch("table tbody tr");

			if($("#busca").val()=="")
			{
				$("#embudo").hide();
			}	
			else
			{
				$("#embudo").show();
			}	

			var e = 0;
			var estado = "";
			$("table tbody tr").each(function()
			{
				estado = $(this).css("display");
				if(estado != "none")
				{
					e++;	
				}
				
			});
				
				
				$("#numeroregistros").text(e);

				
		}
	</script>
</body>
</html>