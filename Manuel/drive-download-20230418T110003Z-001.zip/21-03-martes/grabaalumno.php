<?php
	//recibimos los datos del formulario
	$nom = $_POST['nombre'];
	$ap1 = $_POST['ap1'];
	$ap2 = $_POST['ap2'];
	$ema = $_POST['ema'];
	$pas = password_hash($_POST['pass'], PASSWORD_DEFAULT); //recibimos contraseña y la encriptamos

	//tenemos que unir los apellidos en uno
	$ap = $ap1." ".$ap2;
	// $ap = "$ap1 $ap2"; esto es lo mismo que la línea anterior

	include("clases.php");
	$grabaalumno = new Grabar("alumnos","nom_alu, ap_alu, email_alu, pass_alu", "'$nom', '$ap','$ema','$pas'");
	$grabaalumno->haz_grabar();	



?>