registros = {
    "Nombre":"Alfonso",
    "Ap1":"Carro",
    "Ap2":"Moris",
    "Edad":42
}
# print(registros[0]) YO NO TENGO POSICIONES
print(registros["Nombre"])
# print(registros.keys())
encabezados = registros.keys()
print(encabezados[0])

