# flujos de control
#condicionales
num = 10
if num == 10:
    print("Es igual a 10")
else:
    print("no son iguales")


# condicional anidado

if num == 10:
    print("texto a mostrar")
    if num > 10:
        print("text a mostrar")
    else:
        print("texto a mostrar")
else:
    print("texto a mostrar")            


# condicional else if
if num == 10:
    print("texto a mostrar")
elif num > 10:
    print("texto a mostrar")
else:
    print("texto a mostrar")

# condicional con and y con or
if num > 10 and num <20:
    print("texto a mostrar")
elif num > 100 or num ==200:
    print("texto a mostrar")
        


