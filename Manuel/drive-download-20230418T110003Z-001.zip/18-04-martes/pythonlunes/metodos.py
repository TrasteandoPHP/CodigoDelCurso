nombre = 'alfonso carlos'
print(nombre.count(""))
nombre.upper()
nombre.lower()
nombre = nombre.replace("alfonso","miguel")
print(nombre)
print(nombre.count(""))
print(nombre.find('m'))
print(len(nombre))
print(nombre.index('g'))
trozos = nombre.split()
print(trozos)
texto = "Javier"
texto2 = "Manolo"
print("Buenos dias texto")
print("Buenos dias " + texto)
print(f"Buenos dias {texto}")
print("Buenos dias {0} {1}".format(texto, texto2))







