lista1 = ["Ford","Seat","bmw"]
# lista2 = list("Manzana","Pera","Melocoton")
lista2ok = list(("Manzana","Pera","Melocoton"))
colores = ["Azul","Verde","Naranja","Rojo","Amarillo"]
# imprimir la posición que quiero
print(colores[0])
# tamaño de la lista
print(len(colores))
# hay un dato en una lista???
print('Negro' in colores)
print('Azul' in colores)
# vamos a añadir un elemento nuevo al final de la lista colores
colores.append('Negro')
print('Negro' in colores)
# vamos a añadir más de un elemento
colores.extend(['Morado','Marron','Lila'])
print(len(colores))
print(colores)
# eliminar el último
colores.pop()
print(colores)
# elimniar POR índece el que quiera
colores.pop(2)
print(colores)
# eliminar por valor
colores.remove('Azul')
# meter en la posició que quiera un valor
colores.insert(2,'Plateado')
print(colores)
colores.insert(len(colores),'Dorado')
print(colores)
# ordenando la lista
print("--------------")
colores.sort()
print(colores)
# orden decreciente
colores.sort(reverse=True)
print(colores)
# saber la posición de un elemento
print(colores.index('Morado'))
#vamos a hacer una asignación
colores[0] = 'Rosa'
print(colores)
# vamos a limpiar
colores.clear()
print(colores) 
# borrando la varable
del(colores)
#print(colores) #no se encuentra la variable


