# variables texto
a = "Alfonso"
b = "Carro Moris"

# variables numeros
# integer
c = 1000
# float
d = 2.5

# variables booleanas
e = True
f = False

# variables tipo listas
g = ["Alfonso","Carro","Moris"]
h = [1,2,3]
i = [1.5, 1000, 58.6]
j = ["Alfonso", 42, 1.78, True]

# variables tipo tuplas
k = ("Alfonso", "Carro", "Moris")
l = ()

# variables tipo diccionario
m = {
    "Clave":"Valor",
    "Nombre":"Alfonso",
    "Ap1":"Carro",
    "Ap2":"Moris",
    "Edad":42,
    "Estatura":1.78,
    "Activo":True
}

m = "Alfonso"

m = []

print("Hola mundo")
print(m)




