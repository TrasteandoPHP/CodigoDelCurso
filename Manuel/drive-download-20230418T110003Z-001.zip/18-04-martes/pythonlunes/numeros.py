numero1 = 1
numero2 = 2
suma = numero1 + numero2
print(f"la suma es: {suma}")
print("Dime un numero")
n1 = input()
print("El numero que me acabas de escribir es: "+n1)
n2 = input("Dime otr numero: ")
print("El otro numero que me escribiste es: " +n2)
num1 = input("dime un numero: ")
num2 = input("dime otro numero: ")
sumatodo = num1 + num2
print(sumatodo)

nume1 = int(input("Dime un numero entero: "))
nume2 = int(input("Dime otro numero entero: "))
sumaenteros = nume1 + nume2
print(sumaenteros)


