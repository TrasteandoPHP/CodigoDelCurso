<hmtl>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <?php
            $nom = "ALFONSO";
            $nom2 = "Juan";
            $cmd = escapeshellcmd("prueba.py $nom $nom2");
            $ejcmd = shell_exec($cmd);
            echo "<h1>$ejcmd</h1>";  
        ?>
    </body>
</html>