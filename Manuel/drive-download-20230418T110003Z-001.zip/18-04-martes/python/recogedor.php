<?php

	if(isset($_POST["num1"]))
	{
		$n1 = $_POST["num1"];
		$n2 = $_POST["num2"];
		//vamos a crear la llamada al python
		$cmd =  escapeshellcmd("comprobar.py $n1 $n2");
		$ejcmd = shell_exec($cmd);
		echo $ejcmd;
	}
	else
	{
		header("location:form.html");
	}	

?>