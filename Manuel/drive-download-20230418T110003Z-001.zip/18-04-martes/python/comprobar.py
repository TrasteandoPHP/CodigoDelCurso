import sys
numero1 = int(sys.argv[1])
numero2 = int(sys.argv[2])

if numero1 > numero2:
	print("Numero 1 es mayor")
elif numero1 < numero2:
	print("Numero 2 es mayor")	
else:
	print("Los numeros son iguales")