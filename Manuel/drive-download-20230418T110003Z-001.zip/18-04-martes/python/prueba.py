import sys
nombre = sys.argv[1]
nombre2 = sys.argv[2]
print("Buenos días "+ nombre + nombre2)
