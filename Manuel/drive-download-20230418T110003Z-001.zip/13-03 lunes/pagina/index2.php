<?php
	include("funciones.php");
	cabeza("Página de Pedro");
	cuerpo();
	pie();	
?>