HAZ trocito para hacer un input
	pinta un input en pantalla

HAZ trocito para hace run boton
	pinta un boton en pantalla

HAZ trocito para una etiqueta de enlace
	pinta un enlace

HAZ trocito para insertar una imagen
	pinta una imagen

