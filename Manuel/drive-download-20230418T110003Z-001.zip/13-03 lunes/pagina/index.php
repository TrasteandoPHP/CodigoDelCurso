<?php
	include("funciones.php");
	cabeza("Página de Alfonso");
	menu("#", "home", "Inicio");
	menu("#", "facebook", "Inicio");
	menu("#", "user", "Inicio");
	menu("#", "poo", "Inicio");
	menu("#", "whatsapp", "Inicio");
	cuerpo();
	pie();	
?>