<?php
	$conexion = new mysqli("locahost","root","","cumpleanos");
?>