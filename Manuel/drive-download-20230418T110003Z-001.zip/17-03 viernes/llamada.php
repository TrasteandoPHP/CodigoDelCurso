<?php
	
	//recogemos los datos del formulario

	$nom = $_POST["nombre"];
	$ema = $_POST['email'];
	$ape = $_POST['apellidos'];
	$pas = password_hash($_POST["password"], PASSWORD_DEFAULT);

	include("clases.php");

	$alumno = new Grabar("alumnos","nom_alu,ap_alu, email_alu, pass_alu","'$nom','$ape','$ema','$pas'");
	$alumno->haz_grabar();
	$codalu = $alumno->ultimo();

	//tengo que crear otro objeto porque este no permite consultar

	$busca = new Consultar("alumnos","");
	$numero = $busca->haz_cuenta();
	$busca->cambiarcondicion("WHERE nom_alu = 'Alfonso'");
	if($busca->haz_fetch())
	{	
		$ej = $busca->haz_query();
		foreach ($ej as $reg ) 
		{
			
		}
	}
		









?>