<?php
	$conexion = new mysqli("10.10.10.101","cabreiroa","agua","tienda2");
?>