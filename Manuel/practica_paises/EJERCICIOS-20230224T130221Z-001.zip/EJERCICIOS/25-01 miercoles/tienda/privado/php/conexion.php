<?php
	$conexion = new mysqli("10.10.10.107","cabreiroa","agua","tiendados");
?>